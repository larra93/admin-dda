

   <!-- ======= Footer ======= -->
   <footer id="footer">
    <div class="container">
    <h3>Detalles de Amor</h3>
      <div class="social-links">
        <a href="https://twitter.com/detalledeamor25/" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="https://www.facebook.com/detallitosdeamor25/" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/detalledeamor25/" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="https://api.whatsapp.com/send?phone=56983147461" class="whatsapp"><i class="bx bxl-whatsapp"></i></a>

      </div>
      <h6 style="color: white;">Servicio de despacho a domicilio en Coquimbo y La Serena</h6>
      <div class="copyright">
        &copy; Copyright <strong><span>Detalles de Amor</span></strong>. All Rights Reserved
        
      </div>
      <div class="credits">
        Designed by Felipe Larraguibel
      </div>
    </div>
  </footer><!-- End Footer -->
  





<?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/web/footer.blade.php ENDPATH**/ ?>