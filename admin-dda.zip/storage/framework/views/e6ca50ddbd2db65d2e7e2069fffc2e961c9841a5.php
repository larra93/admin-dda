<?php $__env->startSection('contenido'); ?>  
<?php echo $__env->make('web.funciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<section id="productos" class="portfolio sectionAbout">
  <div class="container">

    <div class="section-title">
    
      <h2 class="wow pulse">Productos</h2>
     
    </div>
    <div class="row portfolio-container  wow fadeInRight">


 
    <?php if($resultados >= 1): ?>
    
    
      <?php $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
      <div class="col-md-4">
        <a href="<?php echo e(route('detalleProducto',$dato->id_producto)); ?>">
        <div class="portfolio-imag"><img src="<?php echo e(asset('images/productos/thumbs/'.$dato->imagen_destacada)); ?>" class="img-fluid"  alt="detalles de amor coquimbo producto"></div>
        <div class="portfolio-info">
            <h4><?php echo e($dato->nombre_producto); ?></h4>
            <p><?php echo e('$'. number_format($dato->precio, 0, ',', '.')); ?></p>
        </div>
    
        </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php else: ?>

    <div class="container detalleProducto">
      <h4>No se encontraron resultados</h4>
      </div>
    
 
  
    

      <?php endif; ?>
    
    </div>
  </div>
  
  
</section>  

    <?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">


$(window).on('load', function() { 
    $(".loader").fadeOut("slow");
     
});
</script>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/web/producto.blade.php ENDPATH**/ ?>