

<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('css'); ?>
   <!-- <link rel="stylesheet" href="/css/admin_custom.css">-->
    <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('/css/toastr.css')); ?>" rel="stylesheet">
    <style>
      .sidebar-dark-primary{
        background: #AD5E99 !important;
      }
      .nav-link.active {
        background-color: #7BC4C4 !important;
      }
 </style>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<div class="alert alert-default-danger" role="alert">
  Servicios
 </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">


<div class="table-responsive-sm">
<table id="servicios" class="table mt-4" style="width: 100%">
  <button class="btn btn-primary"> 
    <a style="color: white" href="servicios/create">Agregar Servicio</a>
</button><br><br>
  <thead class="bg-primary2 text-white">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nombre</th>
      <th scope="col">Descripción</th>
      <th scope="col">Imagen</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody>    
    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $desc = substr($servicio->descripcion_servicio, 0, 50); ?>
    <tr>
        <td><?php echo e($servicio->id_servicio); ?></td>
        <td><?php echo e($servicio->nombre_servicio); ?></td>
        <td><?php echo $desc.'...'; ?></td>
     
        <td><img src="<?php echo e(asset('images/servicios/thumbs/'.$servicio->imagen)); ?>" width=100 > </td>
        <td>

          <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          <div class="row">
          
          <button class="btn btn-round btnEditar"> 
              <a href="<?php echo e(url('admin/servicios/'.$servicio->id_servicio.'/edit')); ?>"><i class="fa fa-edit"></i></a>
          </button>
       
          <form action="<?php echo e(route ('servicios.destroy',$servicio->id_servicio)); ?>" class="form-eliminar" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            
              <button type="submit" class="btn btn-round" style="background-color:transparent;"><i class="fa fa-trash"></i></button>
          </div>
          </form> 
        </td>        
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>
</div>












<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('/js/toastr.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
     <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     <script src="https://cdn.ckeditor.com/ckeditor5/29.2.0/classic/ckeditor.js"></script>
<?php if( session()->has('Result')): ?>

<script>
    $(function(){
        toastr.<?php echo e(session('Result')['status']); ?>('<?php echo e(session('Result')['content']); ?>')
    });

    
</script>
<?php endif; ?>


<script>
    $(document).ready(function() {

      $('.form-eliminar').submit(function(e){
      e.preventDefault();
      Swal.fire({
      title: '¿Estás seguro?',
      text: "Este servicio se eliminara definitivamente",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminar!',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
      this.submit();
      }
    })
})

  function filePreview(input){
    if(input.files && input.files[0]){
      var reader = new FileReader();
      reader.onload = function(e){
        $('#imagenPreview').html("<img width=600 class='img-fluid' src='"+e.target.result+"' />");
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  $('#imagen').change(function(){
    filePreview(this);
  })

    $('#servicios').DataTable({
      "lengthMenu": [[5, 10, 50, -1 ], [5, 10, 50, "Todos"]],
      "language": {
            "lengthMenu": "Mostrar _MENU_ registros ",
            "zeroRecords": "Nada encontrado",
            "info": "Mostrando la página _PAGE_ of _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(Filtrado de _MAX_ registros totales)",
            "search": "Buscar",
            'paginate':{
              'next':'Siguiente',
              'previous':'Anterior'
            }
        }
    });
} );


ClassicEditor
        .create( document.querySelector( '#descripcion' ) )
        .catch( error => {
           
        } );
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/servicio/index.blade.php ENDPATH**/ ?>