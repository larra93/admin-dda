


<?php $__env->startSection('contenido'); ?>  

<section id="about" class="sectionAbout"> 

    <div class="container">
      <div class="section-title">
      <br>
      <br>
      <br>
        
        <h2 class="wow fadeInDown">Sobre Nosotros</h2>
        <div class="row">
          <div class="col-md-6 abouts"> 
              <?php $__currentLoopData = $sobreNosotros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              
            <img src="<?php echo e(asset('/images/about/'.$about->imagen)); ?>" class="img-fluid imagenAbout img-thumbnail wow fadeInLeft" alt="detalles de amor sobre nosotros">
          </div>
    
          <div class="col-md-6 wow fadeInDown abouts" data-wow-delay="0.3s"> 
          <br>
       
      
          <?php echo $about->descripcion; ?>

            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
    
         
    
          
        </div>
      </div>
    
    </div>
    
    </section>
    
    


<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">


$(window).on('load', function() { 
    $(".loader").fadeOut("slow");
     
});
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/web/sobreNosotros.blade.php ENDPATH**/ ?>