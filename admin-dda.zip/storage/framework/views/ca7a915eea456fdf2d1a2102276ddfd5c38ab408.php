


<?php $__env->startSection('contenido'); ?>  

<section id="services" class="services">
	<div class="container">

  <div class="wrap">
		<div class="section-title">
     
      <h2 class="wow pulse">¿Cómo Comprar?</h2>
      
      
        <h3 class="wow pulse">¿Cuáles son las formas de encargo y pago?</h3>
        <br>
       

       <?php $__currentLoopData = $compra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $como_comprar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <p class="pDetalle wow fadeInLeft">
        
        <?php echo $como_comprar->descripcion; ?>

      </p> 
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div>
  </div>
  </div>
    </section>
		<br>
    <br>
    <br>
    <br>
    <br><br>
    
    


<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/web/compra.blade.php ENDPATH**/ ?>