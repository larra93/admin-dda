


<?php $__env->startSection('contenido'); ?>  
<?php echo $__env->make('web.funciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<!-- Revisar lo de los llamados js 
    <div class="loader"></div>-->

<section id="services" class="services">
	<div class="container">
  <div class="wrap">
		<div class="section-title">
     
      <h2 class="wow fadeInDown">Productos</h2>
      
    </div>
		<div class="store-wrapper wow fadeInLeft">
			<div class="category_list">
        
        <?php 
        $categorias= mostrar_categorias();
        $arr = $categorias->fetchAll(PDO::FETCH_ASSOC);
				 foreach ($arr as $dato){?>
					<a href="#" class="category_item" category= <?php echo $dato['alias'];?>><?php echo $dato['nombre_categoria'];?></a>
				<?php } ?>
					
				<a href="#" class="category_item" category="all">Todo</a>
				
			</div>
			<section class="products-list">
      <?php
      $productos= mostrar_productos();
      $resultadoProducto = $productos->fetchAll(PDO::FETCH_ASSOC);    
			foreach ($resultadoProducto as $datoProducto) { ?>
       
				<div class="product-item" category=<?php echo $datoProducto['alias'];?>>
					<a href="<?php echo e(route('detalleProducto',$datoProducto['id_producto'])); ?>"><img class="img-fluid" src="<?php echo e(asset('/images/productos/'.$datoProducto['imagen_destacada'])); ?>" >
                        <a href="<?php echo e(route('detalleProducto',$datoProducto['id_producto'])); ?>"> <?php echo $datoProducto['nombre_producto'] ?> </a>

      
				</div>

			<?php } ?>
				



			</section>
		</div>
	</div>
	</div>
	</section>

    <?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">


$(window).on('load', function() { 
    $(".loader").fadeOut("slow");
     
});
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/web/productos.blade.php ENDPATH**/ ?>