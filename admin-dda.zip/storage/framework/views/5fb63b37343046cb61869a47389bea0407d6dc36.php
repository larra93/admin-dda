


<?php $__env->startSection('contenido'); ?>  

    
<!--<div class="loader"></div>-->

<section id="services" class="services">
	<div class="container">

 

  
		<div class="mt-5">
     
      <h2><?php echo $producto->nombre_producto;?></h2>
      
    </div>
		
    <div class="row">
      <div class="col-md-4">
        <div class="product">
          
            <img src="<?php echo e(asset('/images/productos/'.$producto->imagen_destacada)); ?>" class="img-fluid" id="imageBox" alt="">
          
          <div class="cajaPrecio">
            <h4 style="text-align: center; font-size: 30px;"><?php echo '$'. number_format($producto->precio, 0, ',', '.');?></h4>
            </div> 
          
        
     
    
        

      
      </div>
    </div>
          
      <div class="col-md-8">
        <p class="descripcion_producto" style="text-align: justify"><?php echo $producto->descripcion_producto;?> </p>
      </div>

      <?php if($imagenes > 1): ?>
      <div  class="owl-carousel testimonials-carousel mt-3">
        <?php $__currentLoopData = $productoImagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagenProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <img src="<?php echo e(asset('/images/productos/'.$imagenProducto->imagen)); ?>" alt="desayunos a domicilio coquimbo la serena">
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
      <?php else: ?>
      <?php $__currentLoopData = $productoImagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagenProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="container text-center"><br>
      <img src="<?php echo e(asset('/images/productos/'.$imagenProducto->imagen)); ?>" width="300" class="img-fluid" alt="desayunos a domicilio coquimbo la serena">
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>

      
    </div>
  </div>
  
  <!--
    <div class="row">
  
    
      <div class="product">
        <div class="col-md-4">
          <img src="<?php echo e(asset('/images/productos/'.$producto->imagen_destacada)); ?>" class="img-fluid" id="imageBox" alt="">
        
        <div class="cajaPrecio">
          <h4 style="text-align: center; font-size: 30px;"><?php echo '$'. number_format($producto->precio, 0, ',', '.');?></h4>
          </div> 
        
      </div>
      
    
      <div class="product-small-img">
        <img src="<?php echo e(asset('/images/productos/'.$producto->imagen_destacada)); ?>" id="imageBox" onclick="galery(this)" alt="">
        
        <?php $__currentLoopData = $productoImagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagenProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e(asset('/images/productos/'.$imagenProducto->imagen)); ?>" onclick="galery(this)" alt="desayunos a domicilio coquimbo la serena">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  
  
  </div>
     

      <div class="row">
              <div class="col-sm-12 d-flex justify-content-center">
                  <p style="text-align: justify"><?php echo $producto->descripcion_producto;?> </p>
          </div>
      </div>

    -->
  
  
  </div>


</section>

<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('/vendor2/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor2/jquery.easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor2/waypoints/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor2/counterup/counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor2/owl.carousel/owl.carousel.js')); ?>"></script>
<?php $__env->startSection('js'); ?>
    <script>

      function galery(smallImg) {
        var fullImg = document.getElementById("imageBox");
        fullImg.src=smallImg.src;
      }
    </script>
    
<?php $__env->stopSection(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/web/detalleProducto.blade.php ENDPATH**/ ?>