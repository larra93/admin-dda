

<?php $__env->startSection('title', 'Editar Términos'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">

    <style>
      .sidebar-dark-primary{
        background: #AD5E99 !important;
      }
      .nav-link.active {
        background-color: #7BC4C4 !important;
      }
 </style>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<div class="alert alert-default-danger" role="alert">
    Editar Términos
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('ErrorInsert')): ?>

<div class="col-12 alert alert-danger alert-dismissable fade show" role="alert">
  <h5>Errores:</h5>
<ul>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>  
</div>

<?php endif; ?>
<form action="/admin/terminos/<?php echo e($terminos->id_terminos); ?>"   enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label for="" class="form-label">Descripción</label>
        <textarea class="form-control"  placeholder="Descripción" id="descripcion" name="descripcion"><?php echo htmlspecialchars($terminos->descripcion); ?></textarea>
      </div>
 
 


               
    
  <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>
  <a href="/admin/terminos" class="btn btn-secondary" tabindex="5">Cancelar</a>
</form>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/29.2.0/classic/ckeditor.js"></script>
<script src="<?php echo e(asset('/js/admin.js')); ?>"></script>
<script>


ClassicEditor
    .create( document.querySelector( '#descripcion' ) )
    .catch( error => {
        console.error( error );
    } );

</script>
 
<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-dda\resources\views/terminos/editar.blade.php ENDPATH**/ ?>