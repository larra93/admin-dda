<?php

$link='mysql:host=localhost;dbname=detalled_detallesdeamor';
$usuario='detalled_root';
$pass='larra1993coquimbo';


try {
   $pdo= new PDO($link,$usuario,$pass);
   $pdo->query("SET NAMES 'utf8'");
  

    
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>